import React from 'react'
import Project from 'src/views/dashboards/workstructure/Contact/Component/Project'

function index() {
  return (
    <div>
        <Project/>
    </div>
  )
}

export default index