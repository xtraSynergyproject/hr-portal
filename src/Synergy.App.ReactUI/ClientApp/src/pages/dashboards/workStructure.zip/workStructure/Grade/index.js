import React from 'react'
import Project from '../../../../views/dashboards/workstructure/Grade/Grade/Component/Project'

function index() {
  return (
    <>
    <Project/>
    </>
  )
}

export default index