import React from 'react'
import Project from '../../../../views/dashboards/workstructure/person/Project'

function index() {
  return (
    <div>
        <Project/>
    </div>
  )
}

export default index