import React from 'react'
import Project from '../../../../views/dashboards/workstructure/Department_Hierarchy/Component/Project'

function index() {
  return (
    <div>
        <Project/>
    </div>
  )
}

export default index