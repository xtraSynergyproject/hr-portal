import React from 'react'
import Project from 'src/views/dashboards/workstructure/PositionH/Project'

function index() {
  return (
    <div>
        <Project/>
    </div>
  )
}

export default index