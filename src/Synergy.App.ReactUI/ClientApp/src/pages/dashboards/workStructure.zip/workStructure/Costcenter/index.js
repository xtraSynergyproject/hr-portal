import React from 'react'
import Project from '../../../../views/dashboards/workstructure/Costcenter/Costcenter/Component/Project'

function index() {
  return (
  <>
  <Project/>
  </>
  )
}

export default index