import React from 'react'
import Project from '../../../../views/dashboards/workstructure/Project6/Project6/Component/Project'

function city() {
  return (
    <div>
        <Project/>
    </div>
  )
}

export default city