import React from 'react'
import Project from '../../../../views/dashboards/workstructure/Job/Job/Component/Project'

function index() {
  return (
   <Project/>
  )
}

export default index