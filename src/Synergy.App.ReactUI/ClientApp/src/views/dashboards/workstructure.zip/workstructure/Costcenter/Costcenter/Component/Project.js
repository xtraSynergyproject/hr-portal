import React from 'react'
import Costcenter from './Costcenter'

function Project() {
  return (
    <div>
        {/* <Xyz/> */}
        {/* <New/> */}
        {/* <Payroll/> */}
        <Costcenter/>
    </div>
  )
}

export default Project