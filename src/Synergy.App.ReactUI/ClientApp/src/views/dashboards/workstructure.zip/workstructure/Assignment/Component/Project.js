import React from 'react'
import Assignment from './Assignment'

function Project() {
  return (
    <div>
        <Assignment/>        
    </div>
  )
}

export default Project