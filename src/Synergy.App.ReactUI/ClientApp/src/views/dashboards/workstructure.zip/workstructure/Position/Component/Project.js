import React from 'react'
import Position from './Position'
function Project() {
  return (
    <div>
        <Position/>
    </div>
  )
}

export default Project