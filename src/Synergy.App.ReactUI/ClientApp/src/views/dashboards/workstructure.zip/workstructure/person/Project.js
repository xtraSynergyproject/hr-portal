import React from 'react'
import Person from './Person'
function Project() {
  return (
    <div>
        <Person/>
    </div>
  )
}

export default Project