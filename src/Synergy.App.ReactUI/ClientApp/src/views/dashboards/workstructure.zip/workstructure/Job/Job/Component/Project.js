import React from 'react'
import Job from './Job'
// import Xyz from './Components/Xyz'
// import New from './Components/New'
// import Payroll from './Components/Payroll'
function Project() {
  return (
    <div>
        {/* <Xyz/> */}
        {/* <New/> */}
        {/* <Payroll/> */}
        <Job/>
    </div>
  )
}

export default Project