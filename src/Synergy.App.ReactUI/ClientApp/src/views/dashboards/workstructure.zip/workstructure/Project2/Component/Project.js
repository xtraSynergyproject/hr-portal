import React from 'react'
import Hrdocument from './Hrdocument'
// import Xyz from './Components/Xyz'
// import New from './Components/New'
// import Payroll from './Components/Payroll'
function Project() {
  return (
    <div>
        {/* <Xyz/> */}
        {/* <New/> */}
        {/* <Payroll/> */}
        <Hrdocument/>
    </div>
  )
}

export default Project