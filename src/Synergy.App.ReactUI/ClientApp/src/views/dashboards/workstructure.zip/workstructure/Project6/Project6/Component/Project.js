import React from 'react'
import Hrcity from './Hrcity'
// import Xyz from './Components/Xyz'
// import New from './Components/New'
// import Payroll from './Components/Payroll'
function Project() {
  return (
    <div>
        {/* <Xyz/> */}
        {/* <New/> */}
        {/* <Payroll/> */}
        <Hrcity/>
    </div>
  )
}

export default Project