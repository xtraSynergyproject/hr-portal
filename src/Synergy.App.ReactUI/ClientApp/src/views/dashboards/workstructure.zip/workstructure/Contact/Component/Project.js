import React from 'react'
import Contact from './Contact'

function Project() {
  return (
    <div>
       
        <Contact/>
    </div>
  )
}

export default Project