import React from 'react'
import Department from './Department'

function Project() {
  return (
    <div>
        <Department/>
    </div>
  )
}

export default Project