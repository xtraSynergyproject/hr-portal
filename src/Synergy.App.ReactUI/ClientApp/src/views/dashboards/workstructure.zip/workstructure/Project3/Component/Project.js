import React from 'react'
import Hrcountry from './Hrcountry'
// import Xyz from './Components/Xyz'
// import New from './Components/New'
// import Payroll from './Components/Payroll'
function Project() {
  return (
    <div>
        {/* <Xyz/> */}
        {/* <New/> */}
        {/* <Payroll/> */}
        <Hrcountry/>
    </div>
  )
}

export default Project