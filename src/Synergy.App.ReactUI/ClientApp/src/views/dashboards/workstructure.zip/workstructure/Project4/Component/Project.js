import React from 'react'
import Hrnationality from './Hrnationality'
// import Xyz from './Components/Xyz'
// import New from './Components/New'
// import Payroll from './Components/Payroll'
function Project() {
  return (
    <div>
        {/* <Xyz/> */}
        {/* <New/> */}
        {/* <Payroll/> */}
        <Hrnationality/>
    </div>
  )
}

export default Project