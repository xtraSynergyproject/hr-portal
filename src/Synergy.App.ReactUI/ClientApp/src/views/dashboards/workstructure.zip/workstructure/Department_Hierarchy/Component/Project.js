import React from 'react'
import Departmenth from './Departmenth'

function Project() {
  return (
    <div>
       
        <Departmenth/>
    </div>
  )
}

export default Project