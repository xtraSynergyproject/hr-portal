import React from 'react'
import Hrgrade from './Hrgrade'
// import Xyz from './Components/Xyz'
// import New from './Components/New'
// import Payroll from './Components/Payroll'
function Project() {
  return (
    <div>
        {/* <Xyz/> */}
        {/* <New/> */}
        {/* <Payroll/> */}
        <Hrgrade/>
    </div>
  )
}

export default Project