import React from 'react'
import Hrrlocation from './Hrrlocation'
// import Xyz from './Components/Xyz'
// import New from './Components/New'
// import Payroll from './Components/Payroll'
function Hr() {
  return (
    <div>
        {/* <Xyz/> */}
        {/* <New/> */}
        {/* <Payroll/> */}
      <Hrrlocation/>
    </div>
  )
}
export default Hr