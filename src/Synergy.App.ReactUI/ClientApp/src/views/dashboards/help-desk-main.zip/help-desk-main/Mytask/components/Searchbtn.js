import React from 'react'
import Button from '@mui/material/Button';

export default function Searchbtn() {
  return (
    <Button variant="contained" sx={{height: '40px'}}>
      Search
    </Button>
  );
}