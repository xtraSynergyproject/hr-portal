import * as React from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import Abc from 'src/views/pages/user-profile/Abc'
// import NehaPagal from "./NehaPagal";
import Xyz from 'src/pages/dashboards/Project/Components/Xyz'
import Form from 'src/pages/dashboards/Project/Components/Form'



// import Tabs from 'sr/'

// import StepperLinearWithValidation from 'src/views/forms/form-wizard/StepperVerticalWithoutNumbers'

const modalWrapper = {
  overflow:"auto",
  maxHeight:"100vh",
  display:"flex",
};

const modalBlock = {
  position:"relative",
  zIndex:0,
  display:"flex",
  alignItems:"center",
  justifyContent:"center",
  margin:"auto",
}

const modalContentStyle ={
  position:"relative",
  background:"#fff",
  boxShadow:24,
  mt:3,
  width:"80%",
  height:"80%",
  mb:3,
  borderRadius:"10px",
};

export default function Model() {
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  return (
    <div>
      <Button onClick={handleOpen}>Create</Button>
      <Modal
        open={open}
        sx={modalWrapper}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={modalBlock}>
          <Box sx={modalContentStyle}>


<Abc/>

<Xyz/>
<Form/>
        </Box>
        </Box>
      </Modal>
    </div>
  );
}
